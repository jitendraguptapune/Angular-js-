    /*(function(){
        angular.module('merchantApp',['ngRoute'])
        .config(routeConfigration);
        routeConfigration.$inject=['$routeProvider'];
        function routeConfigration($routeProvider){
            $routeProvider.when('/home',{
               templateUrl :'App/summary/Views/summary.view.html',
                 controller :'Summaryctrl',
                controllerAs :'vm'
            })
            .when('/summary' ,{
                templateUrl :'App/summary/Views/summary.view.html',
                controller : 'Summaryctrl',
                controllerAs :'vm'
            })
            .when('/purchace' ,{
                templateUrl :'App/Purchace_detail/Views/purchacedetail.view.html' 
            })
            .when('/recent' ,{
                templateUrl :'App/Recent_purchace/Views/recent_purchace.view.html' 
            })
            .otherwise({redirectTo:"/home"})
        }
    })();*/
(function(){
   angular.module('merchantApp', ['ui.router'])
   
   
   .config(function($stateProvider,$locationProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise("/summary");
    $stateProvider
    .state('summary', {
      url: "/summary",
      views: {
        "navView": {
            templateUrl :'App/summary/Views/summary.view.html',
            controller : 'Summaryctrl',
            controllerAs :'vm'
      }
      }
    })
    .state('purchace', {
      url: "/purchace/:id",
      views: {
        "navView": {
            templateUrl :'App/Purchace_detail/Views/purchacedetail.view.html',
            controller : 'purchacedetailCtrl',
            controllerAs :'vm'
        }
     
      }
    })
    
    .state('recent', {
      url: "/recent",
      views: {
        "navView": {
            templateUrl :'App/Recent_purchace/Views/recent_purchace.view.html',
             controller : 'recentPurchaceCtrl',
            controllerAs :'vm'
         
        }
      }
    })
    
    
    
}); 

    
})();

(function(){
     angular.module('merchantApp')
     .controller('mainCtrl',mainCtrl);
        mainCtrl.$inject=['$rootScope'];
        function mainCtrl($rootScope){
            var vm=this;
            $rootScope.purchaceTab =false;
        };   
})();
