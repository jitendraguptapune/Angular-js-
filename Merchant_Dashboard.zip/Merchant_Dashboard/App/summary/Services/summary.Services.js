(function(){
    angular.module('merchantApp')
    .service('SummaryService',SummaryService);
    function SummaryService(){
        var ProductData=[
                {
                    ProductId:123,
                    productType:'food',
                    ProductName:'Amul Milk',
                    Brand:"Amul",
                    Price:30,
                   
                },
               {
                    ProductId:456,
                    productType:'cloth',
                    ProductName:'Jeans',
                    Brand:"Lee",
                    Price:1500,
                   
                },
               {
                    ProductId:789,
                    productType:'Mobile',
                    ProductName:'Samsung',
                    Brand:"Samsung",
                    Price:10000,
                   
                },
                {
                    ProductId:789,
                    productType:'Mobile',
                    ProductName:'sony',
                    Brand:"sony",
                    Price:10000,
                   
                },
                 {
                    ProductId:789,
                    productType:'Mobile',
                    ProductName:'max',
                    Brand:"max",
                    Price:10000,
                   
                },
               {
                    ProductId:789,
                    productType:'Mobile',
                    ProductName:'lenovo',
                    Brand:"lenovo",
                    Price:10000,
                   
                },
               {
                    ProductId:789,
                    productType:"Lava",
                    ProductName:'Lava',
                    Brand:"Lava",
                    Price:10000,
                   
                },
                
            ];
                var CategoryData=[
                {
                    CategoryId:1212,
                    CategoryName:'Mobile',
                   
                   
                },
               {
                    CategoryId:4654,
                    CategoryName:'Food',
                   
                },
               {
                    CategoryId:121,
                    CategoryName:'cloths',
                   
                },
                 {
                    CategoryId:8789,
                    CategoryName:'jeans',
                   
                },
                 {
                    CategoryId:456456,
                    CategoryName:'Machine',
                   
                },
                
              ];
                var BrandData=[
                {
                    BrandName:"samsung",
                    BrandItems:'Mobile',
                    BrandDetails:'s4',
                    
                   
                },
               {
                     BrandName:"Max",
                    BrandItems:'Mobile',
                    BrandDetails:'Maxc6',
                   
                },
               {
                     BrandName:"Sony",
                    BrandItems:'Sony Mobile',
                    BrandDetails:'Sony C3',
                   
                },
                
            ];
            this.getAllProductData=function(){
                return ProductData;
            };
            this.getCategoryData=function(){
                return CategoryData;
            };
            this.getBrandData=function(){
                return BrandData;
            };
            /*this.getSingleEvent=function(eid){
                var eventDetails;
                futureEventsData.forEach(function(event){
                    if(event.eventId==eid){
                        eventDetails=event;
                        console.log("event deail..." +event.eventId);
                    }
                });
                return eventDetails;
            };
            this.addNewEvent=function(event){
                futureEventsData.push(event);
            };*/
    };

})();