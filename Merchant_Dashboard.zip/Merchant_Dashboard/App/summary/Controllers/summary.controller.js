(function(){
    angular.module('merchantApp')
    .controller('Summaryctrl' , Summaryctrl);
    Summaryctrl.$inject=['SummaryService','$stateParams','$location' , '$scope' ,'$rootScope'];
     function Summaryctrl(SummaryService,$stateParams,$location ,$scope ,$rootScope){
            var vm=this;
           $rootScope.purchaceTab =false;
            vm.details={};
            vm.product=function(){
                vm.productData=SummaryService.getAllProductData();
            };
            vm.Category=function(){
                vm.CategoryData=SummaryService.getCategoryData();
            };
            vm.brand=function(){
                vm.brandData=SummaryService.getBrandData();
            };
            vm.divShow = "div1"
            vm.handleShowHide = function(arg){
                vm.divShow = arg;
    
         
            }
            
        };

})();