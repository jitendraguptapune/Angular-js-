(function(){
    angular.module('merchantApp' ,[])
    .directive('sideBar' , generateSidebar);
    function generateSidebar(){
        return{
            
            templateUrl :'App/summary/Views/summary.sidebar.directive.html'
        }
    }
})();