(function(){
    angular.module('merchantApp')
    .controller('recentPurchaceCtrl' ,recentPurchaceCtrl);
    recentPurchaceCtrl.$inject=['recentService'];
    function recentPurchaceCtrl(recentService ){
        var vm= this;
        vm.details={};
        vm.recentPurchace=function(){
                vm.recentData=recentService.getAllrecentData();
        };
      /*  vm.singleProduct=function(){
                var id=$stateParams.id;
                 vm.details=recentService.getSingleProduct(id)
        };*/
    }
})();