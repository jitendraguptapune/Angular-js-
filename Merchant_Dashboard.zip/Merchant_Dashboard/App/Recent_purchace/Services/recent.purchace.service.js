(function(){
    angular.module('merchantApp')
    .service('recentService',recentService);
    function recentService(){
        var recentPurchaceData=[
                {
                    id:1,
                    ProductId:45454,
                    Product:'Mobile',
                    Price:3000,
                    Quantity:2,
                    Buyer_Name : "vikas"
                    
                   
                },
               {
                   id:2,
                     ProductId:45454,
                    Product:'Milk',
                    Price:30,
                    Quantity:2,
                    Buyer_Name : "Vijay"
                   
                },
               {
                   id:3,
                     ProductId:78787,
                    Product:'cloth',
                    Price:3000,
                    Quantity:2,
                    Buyer_Name : "shailesh"
                   
                },
              {
                   id:4,
                     ProductId:46464,
                    Product:'cloth',
                    Price:1500,
                    Quantity:2,
                    Buyer_Name : "namo"
                   
                },
                 {
                   id:5,
                     ProductId:78787,
                    Product:'Food',
                    Price:30,
                    Quantity:2,
                    Buyer_Name : "harish"
                   
                },
             {
                   id:6,
                     ProductId:13121,
                    Product:'Food',
                    Price:30,
                    Quantity:3,
                    Buyer_Name : "vinit"
                   
                },
                
            ];
               
            this.getAllrecentData=function(){
                return recentPurchaceData;
            };
             this.getSingleProduct=function(eid){
                var productDetails;
                recentPurchaceData.forEach(function(product){
                    if(product.id==eid){
                        productDetails=product;
                       // console.log("event deail..." +employee.employeeId);
                    }
                });
                return productDetails;
        };
           
          
    };

})();