(function(){
    angular.module('merchantApp')
    .controller('purchacedetailCtrl' , purchacedetailCtrl)
    purchacedetailCtrl.$inject=['recentService','$stateParams','$rootScope'];
    function purchacedetailCtrl(recentService ,$stateParams ,$rootScope){
        var vm =this;
         $rootScope.purchaceTab =true;
          vm.details={};
            var id=$stateParams.id;
                 vm.details=recentService.getSingleProduct(id)
         vm.singleProduct=function(){
                
        };
        
    }
})();